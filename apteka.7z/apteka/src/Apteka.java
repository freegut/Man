public class Apteka {
    private String name;
    private String[] medicines;
    private int[] prices;

    public Apteka(String name, String[] medidcines, int[] prices) {
        this.name = name;
        this.medicines = medidcines;
        this.prices = prices;
    }

    public void show() {
        System.out.println("Название аптеки: " + this.name);

        for(int i = 0; i < this.medicines.length; ++i) {
            String var10001 = this.medicines[i];
            System.out.println("Лекарство: " + var10001 + ", Цена: " + this.prices[i]);
        }

    }

    public int MostExpensiveMedicine() {
        int maxPrice = this.prices[0];
        int[] var2 = this.prices;
        int var3 = var2.length;

        for(int var4 = 0; var4 < var3; ++var4) {
            int price = var2[var4];
            if (price > maxPrice) {
                maxPrice = price;
            }
        }

        return maxPrice;
    }

    public int TotalCost() {
        int totalCost = 0;
        int[] var2 = this.prices;
        int var3 = var2.length;

        for(int var4 = 0; var4 < var3; ++var4) {
            int price = var2[var4];
            totalCost += price;
        }

        return totalCost;
    }
}