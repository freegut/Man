public class Main {
    public Main() {
    }

    public static void main(String[] args) {
        String[] meds1 = new String[]{"Аспирин", "Парацетрамон", "Ношпа"};
        int[] pricas1 = new int[]{50, 80, 100};
        Apteka Apteka1 = new Apteka("Аптека №1", meds1, pricas1);
        Apteka1.show();
        System.out.println("Самое дорогое лекарство: " + Apteka1.MostExpensiveMedicine());
        System.out.println("Общая стоимость всех лекарств: " + Apteka1.TotalCost());
        String[] meds2 = new String[]{"Нурафен", "Пардифен", "Витамин"};
        int[] pricas2 = new int[]{120, 70, 150};
        Apteka Apteka2 = new Apteka("Аптека №2", meds2, pricas2);
        Apteka2.show();
        System.out.println("Самое дорогое лекарство: " + Apteka2.MostExpensiveMedicine());
        System.out.println("Общая стоимость всех лекарств: " + Apteka2.TotalCost());
    }
}
