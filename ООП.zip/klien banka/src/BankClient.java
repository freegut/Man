import java.util.ArrayList;

public class BankClient {
    private String name; // Имя клиента
    private String passportNumber; // Паспорт клиента
    private int accountCount; // Количество счетов клиента
    private ArrayList<Account> accounts; // Счета клиента

    public BankClient(String name, String passportNumber) {   // Конструктор класса
        this.name = name;                                     // КЛИЕНТ
        this.passportNumber = passportNumber;
        this.accountCount = 0;
        this.accounts = new ArrayList<>();
    }


    public String getName() { // Получить имя

        return name;
    }

    public void setName(String name) { // Присвоить имя

        this.name = name;
    }

    public String getPassportNumber() { // Получить номер паспорта
        return passportNumber;
    }

    public void setPassportNumber(String passportNumber) { // Присвоить номер паспорта

        this.passportNumber = passportNumber;
    }

    public int getAccountCount() { // Получить количество счетов

        return accountCount;
    }

    public void setAccountCount(int accountCount) { // Присвоить количество счетов (лучше не использовать, оно все поломает)

        this.accountCount = accountCount;
    }

    public void addAccount(Account account) { // Добавить счет
        accounts.add(account);
        accountCount += 1;
    }

    public void removeAccount(Account account) { // Удалить счет
        accounts.remove(account);
        accountCount -= 1;
    }

    public ArrayList<Account> getAccounts() { // Получить список счетов
        return accounts;
    }

    public double getTotalPercent() {   // В этом методе мы возвращаем общую сумму процентов одного клиента
        double totalPercent = 0;
        for (Account account : accounts) {                  // Функция for each. Что делает:
            totalPercent += account.calculatePercent();    // Переменная account будет последовательно принимать значения каждого элемента
        }                                                   // списка accounts, и внутри цикла можно выполнять операции с каждым элементом.
        return totalPercent;
    }

    public static BankClient getClientWithMaxPercent(ArrayList<BankClient> clients) {   // В этом методе мы находим клиента
        BankClient clientWithMaxPercent = null;                                         // с самой большой суммой процентов

        double maxPercent = Double.MIN_VALUE; // Для нахождения наибольшей суммы процентов присваиваем минимальное значение типа double
        for (BankClient client : clients) {   // Снова функция for each
            double totalPercent = client.getTotalPercent();
            if (totalPercent > maxPercent) {  // Сравниевам суммы клиентов и клиента с наибольшей суммой
                maxPercent = totalPercent;
                clientWithMaxPercent = client;
            }
        }
        return clientWithMaxPercent; // Получаем клиента с набольшей суммой процентов
    }

    public static void transferDeposit(Account senderAccount, Account receiverAccount, double deposit) {
        if (senderAccount.getBalance() >= deposit) { // Сравнием хочет ли клиент передать больше чем у него есть
            senderAccount.withdraw(deposit);    // Берем деньги у отправителя если их хватает
            receiverAccount.deposit(deposit);   // И передаем получателю
            System.out.println("Деньги перечислены");
        } else {
            System.out.println("На счете отправителя недостаточно средств");
        }
    }
    public static ArrayList<BankClient> getClientLongestDeposits(ArrayList<BankClient> clients) { // Этот метод используется для
        ArrayList<BankClient> clientsLongestDeposit = new ArrayList<>();                          // получения клиентов со вкладом на 2 года и более
        for (BankClient client : clients) {     // Снова for each
            boolean hasLongestDeposits = false; // Переменная для поиска длительного вклада и прерывания цикла
            for (Account account : client.getAccounts()) { // Еще for each
                if (account.getDurationInYears() >= 2) {   // Условие на вклад на 2 года и более
                    hasLongestDeposits = true;  // Меняем если удовлетворяет условиям
                    break;                      // И прерываем цикл
                }
            }
            if (hasLongestDeposits) {
                clientsLongestDeposit.add(client); // Закидываем в список клиентов с длительным вкладом
            }
        }
        return clientsLongestDeposit; // Получаем список с длительным вкладом
    }


}

