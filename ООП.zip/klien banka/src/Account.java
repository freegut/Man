public class Account {
    private int accountNumber; // Номер счета
    private double percent; // Проценты счета
    private double deposit; // Сумма вклада
    private String openDate; // Дата открытия счета
    private String closeDate; // Дата закрытия счета

    public Account(int accountNumber, double percent, double deposit, String openDate, String closeDate) { // Конструктор класса
        this.accountNumber = accountNumber;                                                                // АККАУНТ
        this.percent = percent;
        this.deposit = deposit;
        this.openDate = openDate;
        this.closeDate = closeDate;
    }

    public int getAccountNumber() {
        return accountNumber;
    } // Получить номер аккаунта

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    } // Присвоить номер аккаунта

    public double getPercent() {
        return percent;
    } // Получить проценты

    public void setPercent(double percent) {
        this.percent = percent;
    } // Присвоить проценты

    public double getDeposit() {
        return deposit;
    } // Получить сумму счета

    public void setDeposit(double deposit) {
        this.deposit = deposit;
    } // Присвоить сумму счета

    public String getOpenDate() {
        return openDate;
    } // Получить дату открытия счета

    public void setOpenDate(String openDate) {
        this.openDate = openDate;
    } // Присвоить дату открытия счета

    public String getCloseDate() {
        return closeDate;
    } // Получить дату закрытия счета

    public void setCloseDate(String closeDate) {
        this.closeDate = closeDate;
    } // Присвоить дату закрытия счета
    public double calculatePercent() { // расчет процентов
        return deposit * percent;
    } // Рассчитать проценты по счету

    public int getDurationInYears() { //Получить длительность в годах
        // Даты открытия и закрытия счета должны быть в формате "ДД-ММ-ГГГГ" (День-Месяц-Год)
        int openYear = Integer.parseInt(openDate.substring(6));     // Убираем лишние символы, чтобы остался только год
        int closeYear = Integer.parseInt(closeDate.substring(6));   // Убираем лишние символы, чтобы остался только год
        return closeYear - openYear; // Возвращаем разницу в годах
    }

    public double getBalance() { //Показать баланс по счету
        return deposit;
    } // Получить сумму счета

    public void withdraw(double amount) { // Взять деньги со счета
        deposit -= amount;
    } // Снять деньги со счета

    public void deposit(double amount) { // Положить деньги на счет
        deposit += amount;
    } // Положить деньги на счет
}