import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Создаем несколько клиентов
        BankClient client1 = new BankClient("Алексей", "123456789");
        BankClient client2 = new BankClient("Иван", "987654321");
        BankClient client3 = new BankClient("Виктор", "456789123");

        // Создаем счета отдельно и добавляем их к аккаунту клиента банка
        Account account1 = new Account(1, 0.5, 1500, "01-01-2020", "01-01-2023");
        Account account12 = new Account(2, 0.2, 3000, "01-01-2020", "01-01-2023");

        Account account2 = new Account(1, 0.6, 2500, "01-01-2019", "01-01-2024");
        Account account22 = new Account(2, 0.1, 2000, "01-01-2019", "01-01-2024");

        // Добавляем счета к клиентам
        client1.addAccount(account1);   // Добавляем счет
        client1.addAccount(account12);  // Добавляем счет
        System.out.println("Счетов у клиента1: " + client1.getAccountCount());
        client2.addAccount(account2);   // Добавляем счет
        client2.addAccount(account22);  // Добавляем счет
        System.out.println("Счетов у клиента2: " + client2.getAccountCount());

        // Часть кода для проверки добавления/удаления
        client1.removeAccount(account1);    // Удаляем счет
        System.out.println("Счетов у клиента1: " + client1.getAccountCount());
        client1.addAccount(account1);       // Добавляем счет
        System.out.println("Счетов у клиента1: " + client1.getAccountCount());
        System.out.println(); // Пропуск строки

        // Делаем перевод средств со счета одного клиента на счет другого
        BankClient.transferDeposit(account1, account2, 600); // Используем метод класса BankClient
        System.out.println(); // Пропуск строки

        // Создаем список клиентов, для того чтобы проверить у кого из них есть вклад на 2 года и больше
        ArrayList<BankClient> B = new ArrayList<BankClient>();
        B.add(client1); //Добавляем в список клиентов клиента1
        B.add(client2); //Добавляем в список клиентов клиента2
        ArrayList<BankClient> Max = BankClient.getClientLongestDeposits(B); // Вызываем созданный метод класса BankClient

        System.out.println("Вклад 2 года и больше у: ");
        for (BankClient K : Max) // Перебираем полученные значения
        {
            System.out.println(K.getName()); // Выводим нужных нам клиентов
        }
        System.out.println(); // Пропуск строки

        // Получаем клиента с максимальным значением процентов
        BankClient Maximus = BankClient.getClientWithMaxPercent(B);
        System.out.println("Самое большое значение процентов у клиента: " + Maximus.getName()); // Выводим нужного нам клиента
        System.out.println(); // Пропуск строки

        System.out.println("Длительность вклада счет1 у клиента1: " + account1.getDurationInYears() + " года/лет/год"); // Использование метода из класса Account
        System.out.println(); // Пропуск строки

        System.out.println("Сумма, которую получит клиент2 по счету22, составляет: " + account22.calculatePercent() + "руб"); // Использование метода из класса Account

    }
}