public class Main {
    public static void main(String[] args) {
    String[] meds1 = {"Аспирин", "Парацестамол" , "Ношпа"};
    int[] pricas1 ={50, 80, 100};
    Apteka Apteka1 = new Apteka("Аптека №1", meds1, pricas1 );
    Apteka1.show();
    System.out.println("Самое дарагое лекарство: " + Apteka1.MostExpensiveMedicine());
    System.out.println("Общая стоимость всех лекарств: " + Apteka1.TotalCost());

    String[] meds2 = {"Нурафен", "Пардифен" , "Витамин"};
    int[] pricas2 = {120, 70 , 150};
    Apteka Apteka2 = new Apteka("Аптека №2", meds2, pricas2);
    Apteka2.show();
        System.out.println("Самое дарагое лекарство: " + Apteka2.MostExpensiveMedicine());
        System.out.println("Общая стоимость всех лекарств: " + Apteka2.TotalCost());
    }
}