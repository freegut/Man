public class Apteka {
    private String name;
    private String[] medicines;
    private int[] prices;
    public Apteka(String name , String[] medidcines, int[] prices){
        this.name = name;
        this.medicines = medidcines;
        this.prices = prices;
    }
    public void show() {
        System.out.println("Название аптеки: " + name);
        for (int i = 0; i < medicines.length; i++){
            System.out.println("Лекарство: " + medicines[i] + ", Цена: " + prices[i]);
        }
    }
    public int MostExpensiveMedicine() {
        int maxPrice = prices[0];
        for (int price : prices) {
            if (price > maxPrice) {

            }
        }
        return maxPrice;
    }
    public int TotalCost(){
        int totalCost = 0;
        for (int price : prices){
            totalCost += price;
        }
        return totalCost;
    }
}
